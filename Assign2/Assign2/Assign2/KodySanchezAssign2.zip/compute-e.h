#ifndef COMPUTE_E_H
#define COMPUTE_E_H
class e
{
public:
	e();
	~e();
	double computeNthe(int);
};

#endif