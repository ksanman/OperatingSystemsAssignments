#ifndef COMPUTE_FIB_H
#define COMPUTE_FIB_H

class Fib
{
public:
	Fib();
	~Fib();	
	int computeNthFib(int);
};

#endif